The application requires following platform versions:
MS Excel 2010, Qlikview version 11.20.12742.0,
IBM SPSS 16 Modeler

Input file: NTUC_Market_basket_data.xlsx, NTUC_NPS_data.xlsx ,NTUC_Spend_prediction_data.xlsx,Retail_regular_fashion_NTUC_data.xlsx ,bubble graph - segment.xlsx
Path for input file: REGULAR-MERCHANDISE/NTUC/DataFiles/Regular_Merchandise

Output file: Qlikview report
Path for output file: REGULAR-MERCHANDISE/NTUC/Qlikview files/Regular_Merchandise