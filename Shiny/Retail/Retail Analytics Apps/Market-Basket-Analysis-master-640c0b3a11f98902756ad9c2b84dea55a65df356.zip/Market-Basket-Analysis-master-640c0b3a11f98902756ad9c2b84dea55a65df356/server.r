#onetwo
library(arules)
library(arulesViz)
library(DT)
library(data.table)
library(googleVis)
library(stringr)
library(colorspace)
library(ggplot2)

source("helper.r")

# fulldata <- readRDS("D:\\Shiny\\Market_Basket\\data\\NTUC_market_basket.rds")

shinyServer(function(input, output) {
  
  output$startDateUI <- renderUI({
    myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
    
    query="SELECT min([Transaction_date]) as min_date,max([Transaction_date]) as max_date
    from [dbo].NTUC_data_mart"
    
    result_date=sqlQuery(myconn, query)
    result_min_date=as.Date(result_date$min_date)
    result_max_date=as.Date(result_date$max_date)
    final_result_date=c(result_min_date,result_max_date)
    dateInput("startDateServ",label="Start Date",min=min(final_result_date),max = max(final_result_date),format = "yyyy-mm-dd", value = min(final_result_date))
    
  })
  
  
  output$endDateUI <- renderUI({
    myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
    
    
    
    query="SELECT min([Transaction_date]) as min_date,max([Transaction_date]) as max_date
    from [dbo].NTUC_data_mart"
    
    result_date=sqlQuery(myconn, query)
    result_min_date=as.Date(result_date$min_date)
    result_max_date=as.Date(result_date$max_date)
    final_result_date=c(result_min_date,result_max_date)
    dateInput("endDateServ",label="End Date",min=min(final_result_date),max = max(final_result_date),format = "yyyy-mm-dd", value = max(final_result_date) )
    
    
  })
 
  output$store <- renderUI({
    
    myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
    query="SELECT distinct([Store_No]) as store_name from dbo.NTUC_data_mart"   
    result_store=sqlQuery(myconn, query)
    result_store<-unique(as.character(result_store$store_name))
    selectInput(inputId = "storeListServ",label = "Store",choices = result_store,multiple = TRUE,selected =result_store[1])
    
  })
  
 
  output$ageUI <- renderUI({
    
    myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
    query="SELECT min([Age]) as min_age,max([Age]) as max_age
    from [dbo].NTUC_data_mart"
    result_age=sqlQuery(myconn, query)
    result_min_age=as.numeric(result_age$min_age)
    result_max_age=as.numeric(result_age$max_age)
    final_result_age=c(result_min_age,result_max_age)
    sliderInput(inputId = "ageServ",label = "Age", min = min(final_result_age), max = max(final_result_age),step = 1, value = c(final_result_age[1],final_result_age[2])  )
    
    
  })
  
  
#   output$itemCategory <- renderUI({
#     
#     selectInput(inputId = "itemCategoryServ",label = "Item Category",choices = unique(as.character(fulldata$Item_Category_Code_Desc)),multiple = TRUE,selected = unique(as.character(fulldata$Item_Category_Code_Desc))[1])
#     
#   })
  
  
  v<-reactiveValues(
    condvar1=1
  )
  
  
  
  
  observeEvent(input$getRules, {
    v$condvar1<-v$condvar1 +1
    
  })
  
  
   initialdata <- dataIncludingSales(startDate ="1/1/2010",
                                     endDate="1/1/2015",
                                     stores = c("S0001"),
                                     whatday = c("Weekday"),
                                     age=c(20,60),
                                     gender= c("Male"),
                                     categoryLevel = "Level 1"
                                     )
  

   

 # this table will have other dimensions as well
  reactiveFilteredDataIncludingSales <- reactive({
    
    input$getRules
    isolate(
    dataIncludingSales(startDate = input$startDateServ,
                       endDate  = input$endDateServ,
                       stores =input$storeListServ,
                       whatday = input$Day,
                       age = input$ageServ,
                       gender = input$gender,
                       categoryLevel  =input$poductCategoryLevel
                       ))
    
  })
 
  
  
  
  output$top10TransactionFrequency <- renderDataTable({
    
    if(v$condvar1 == 1){
      
      currentTop10itemFrequencyTable <- initialdata
      currentTop10itemFrequencyTable <- as.data.frame(table(as.data.frame(currentTop10itemFrequencyTable[,8])))
      currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[currentTop10itemFrequencyTable[,2] > 0,]
      currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[order(-currentTop10itemFrequencyTable$Freq),]
      currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[1:5,1]
      
      transdataFreq <- initialdata
      categoryLevel <- colnames(transdataFreq)[8]
      transdataFreq <- split(transdataFreq[,eval(categoryLevel)],transdataFreq$Receipt_No)
      listData <- list()
      for (i in 1:length(transdataFreq)) {
        listData[[i]] <- as.character(transdataFreq[[i]][!duplicated(transdataFreq[[i]])])
      }
      
      # changing class of transdata
      transdataFreq <- as(listData,"transactions")
      ruletable <- data.frame()
      for(i in 1:5){
        rule <- apriori(data=transdataFreq, parameter=list(supp=0.01,conf = 0.05,minlen=2), 
                        appearance = list(default="rhs",lhs=currentTop10itemFrequencyTable[i]),
                        control = list(verbose=F))
        subset.matrix <- is.subset(rule, rule)
        subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
        redundant <- colSums(subset.matrix, na.rm=T) >= 1
        rules.pruned <- rule[!redundant]
        rule <- rules.pruned
        quality(rule) <- round(quality(rule),digits = 4)
        rule <- unique(rule)
        
        rule <- as(rule,"data.frame")
        if(length(rule)==0){
          next
        }else{
        rule <- rule[rule$support > 0 & rule$confidence > 0,]
        rule <- rule[order(- rule$lift),]
        rule <- rule[1,]
        ruletable <- rbind(ruletable,rule)
        remove(rule)
        }
      }
      rownames(ruletable) <- NULL
      ruletable
      
    }else{
      
    currentTop10itemFrequencyTable <- reactiveFilteredDataIncludingSales()
    currentTop10itemFrequencyTable <- as.data.frame(table(as.data.frame(currentTop10itemFrequencyTable[,8])))
    currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[currentTop10itemFrequencyTable[,2] > 0,]
    currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[order(-currentTop10itemFrequencyTable$Freq),]
    currentTop10itemFrequencyTable <- currentTop10itemFrequencyTable[1:5,1]
    
    transdataFreq <- reactiveFilteredDataIncludingSales()
    categoryLevel <- colnames(transdataFreq)[8]
    transdataFreq <- split(transdataFreq[,eval(categoryLevel)],transdataFreq$Receipt_No)
    listData <- list()
    for (i in 1:length(transdataFreq)) {
      listData[[i]] <- as.character(transdataFreq[[i]][!duplicated(transdataFreq[[i]])])
    }
    
    # changing class of transdata
    transdataFreq <- as(listData,"transactions")
    ruletable <- data.frame()
    for(i in 1:5){
      rule <- apriori(data=transdataFreq, parameter=list(supp=0.01,conf = 0.05,minlen=2), 
                      appearance = list(default="rhs",lhs=currentTop10itemFrequencyTable[i]),
                      control = list(verbose=F))
      subset.matrix <- is.subset(rule, rule)
      subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
      redundant <- colSums(subset.matrix, na.rm=T) >= 1
      rules.pruned <- rule[!redundant]
      rule <- rules.pruned
      quality(rule) <- round(quality(rule),digits = 4)
      rule <- unique(rule)
      
      rule <- as(rule,"data.frame")
      if(length(rule)==0){
        next
      }else{
      rule <- rule[rule$support > 0 & rule$confidence > 0,]
      rule <- rule[order(- rule$lift),]
      rule <- rule[1,]
      ruletable <- rbind(ruletable,rule)
      remove(rule)
      }
    }
    rownames(ruletable) <- NULL
    ruletable
    }
    


  
    },options = list(
      lengthChange = FALSE,
      searching = FALSE,
      pageLength = 25,
      orderClasses = TRUE),
    rownames = FALSE,
    colnames =c("Association","Support","Confidence","Lift"))
  
  
  output$top10Sales <- renderDataTable({
    
    if(v$condvar1 == 1){
      
      salesData <- initialdata
      colnames(salesData)[8] <- "Product_Group_Code_Desc"
      salesData <- as.data.table(salesData)
      salesData <- salesData[,list(sumSales=sum(Price)),by=list(Product_Group_Code_Desc)]
      salesData <- salesData[order(-salesData$sumSales),]
      salesData <- as.data.frame(salesData)
      salesData <- salesData[1:5,1]
      
      transdataSales <- initialdata
      categoryLevel <- colnames(transdataSales)[8]
      transdataSales <- split(transdataSales[,eval(categoryLevel)],transdataSales$Receipt_No)
      listData <- list()
      for (i in 1:length(transdataSales)) {
        listData[[i]] <- as.character(transdataSales[[i]][!duplicated(transdataSales[[i]])])
      }
      
      # changing class of transdata
      transdataSales <- as(listData,"transactions")
      ruletable <- data.frame()
      for(i in 1:5){
        rule <- apriori(data=transdataSales, parameter=list(supp=0.01,conf = 0.05,minlen=2), 
                        appearance = list(default="rhs",lhs=salesData[i]),
                        control = list(verbose=F))
        subset.matrix <- is.subset(rule, rule)
        subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
        redundant <- colSums(subset.matrix, na.rm=T) >= 1
        rules.pruned <- rule[!redundant]
        rule <- rules.pruned
        quality(rule) <- round(quality(rule),digits = 4)
        rule <- unique(rule)
        
        rule <- as(rule,"data.frame")
        if(length(rule)==0){
          next
        }else{
        rule <- rule[rule$support > 0 & rule$confidence > 0,]
        rule <- rule[order(- rule$lift),]
        rule <- rule[1,]
        ruletable <- rbind(ruletable,rule)
        }
        
        remove(rule)
      }
      ruletable
      rownames(ruletable) <- NULL
      ruletable <- ruletable[complete.cases(ruletable),]
      
      
    }else{
    
    salesData <- reactiveFilteredDataIncludingSales()
    colnames(salesData)[8] <- "Product_Group_Code_Desc"
    salesData <- as.data.table(salesData)
    salesData <- salesData[,list(sumSales=sum(Price)),by=list(Product_Group_Code_Desc)]
    salesData <- salesData[order(-salesData$sumSales),]
    salesData <- as.data.frame(salesData)
    salesData <- salesData[1:5,1]
    
    transdataSales <- reactiveFilteredDataIncludingSales()
    categoryLevel <- colnames(transdataSales)[8]
    transdataSales <- split(transdataSales[,eval(categoryLevel)],transdataSales$Receipt_No)
    listData <- list()
    for (i in 1:length(transdataSales)) {
      listData[[i]] <- as.character(transdataSales[[i]][!duplicated(transdataSales[[i]])])
    }

    # changing class of transdata
    transdataSales <- as(listData,"transactions")
    ruletable <- data.frame()
    for(i in 1:5){
      rule <- apriori(data=transdataSales, parameter=list(supp=0.01,conf = 0.05,minlen=2), 
                appearance = list(default="rhs",lhs=salesData[i]),
                 control = list(verbose=F))
      subset.matrix <- is.subset(rule, rule)
      subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
      redundant <- colSums(subset.matrix, na.rm=T) >= 1
      rules.pruned <- rule[!redundant]
      rule <- rules.pruned
      quality(rule) <- round(quality(rule),digits = 4)
      rule <- unique(rule)
      
      rule <- as(rule,"data.frame")
      if(length(rule)==0){
        next
      }else{
      rule <- rule[rule$support > 0 & rule$confidence > 0,]
      rule <- rule[order(- rule$lift),]
      rule <- rule[1,]
      ruletable <- rbind(ruletable,rule)
      remove(rule)
      }
    }
    
    rownames(ruletable) <- NULL
    ruletable
    }

  
    
    },options = list(
      lengthChange = FALSE,
      searching = FALSE,
      pageLength = 25,
      orderClasses = TRUE),
    rownames = FALSE,
    colnames =c("Association","Support","Confidence","Lift"))
  
  
  output$top10Affinity <- renderPlot({
    
    
    if(v$condvar1 == 1){
      basket <- getAssociationRules(initialdata)
      basket <- sort(basket, by="lift", decreasing=TRUE)
      basket <- basket[1:10,]
      basket <- plot(basket,method="grouped", shading = "lift",control=list(col=sequential_hcl(20, h = c(-309,0),c=c(400,500), l = c(37, 100),p=1.6), main="Top 10 Associations",aggr.fun=sum))
      basket
      
      
    }else{
    
    basket <- getAssociationRules(reactiveFilteredDataIncludingSales())
    basket <- sort(basket, by="lift", decreasing=TRUE)
    basket <- basket[1:10,]
    
    
    
#     dfrule <- as(basket, "data.frame")
#     split <- str_split_fixed(dfrule$rules," => ",2)
#     dfrule <- dfrule[,-1]
#     colnames(split) <-c("lhs","rhs") 
#     dfrule <- cbind(split,dfrule)
#     p <- ggplot(dfrule,aes(rhs,lhs))+
#       geom_point(aes(size=lift^3,colour=support))
#       scale_size_identity()+
#       scale_color_gradient(low="red",high ="orange")+
#       theme(axis.line=element_blank(),
#             panel.grid.major=element_blank(),
#             panel.grid.minor=element_blank(),
#             plot.background=element_blank(),
#             panel.background=element_blank()
#       )
#     p
#  
#     
    basket <- plot(basket,method="grouped", shading = "lift",control=list(col=sequential_hcl(20, h = c(-309,0),c=c(400,500), l = c(37, 100),p=1.6), main="Top 10 Associations",aggr.fun=sum))
    basket
    }
    
  })
  
  
  
  output$productCatecoryLevelSelectedTab2UI <- renderUI({
    
    choices  <- switch(input$poductCategoryLevel,
                       "Level 1" = "Product_Group_Code_Desc",
                       "Level 2" = "Level_3_Code_Desc",
                       "Level 3" = "ItemNo_Code_Desc"
                       )
    choices <- if(v$condvar1==1){
      choices <- initialdata[,eval(choices)]
    }else{reactiveFilteredDataIncludingSales()[,eval(choices)]}
    choices <- as.character(unique(choices))
    
    selectInput(inputId = "productCatecoryLevelSelectedTab2Serv",label = "",
                choices =choices,multiple = FALSE )
    
   
  })
  
  
  
  output$customRulesPlot <- renderPlot({
    
#     if(input$lhsrhs=="Before"){
#       transdataCustom <- reactiveFilteredDataIncludingSales()
#       categoryLevel <- colnames(transdataCustom)[8]
#       transdataCustom <- split(transdataCustom[,eval(categoryLevel)],transdataCustom$Receipt_No)
#       listData <- list()
#       for (i in 1:length(transdataCustom)) {
#         listData[[i]] <- as.character(transdataCustom[[i]][!duplicated(transdataCustom[[i]])])
#       }
#       
#       # changing class of transdata
#       transdataCustom <- as(listData,"transactions")
#       rule <- apriori(data=transdataCustom, parameter=list(supp=0.01,conf = 0.001,minlen=2), 
#                       appearance = list(default="lhs",rhs=input$productCatecoryLevelSelectedTab2Serv),
#                       control = list(verbose=F))
#       # removing redundant rules
#       subset.matrix <- is.subset(rule, rule)
#       subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
#       redundant <- colSums(subset.matrix, na.rm=T) >= 1
#       rules.pruned <- rule[!redundant]
#       rule <- rules.pruned
#       
#       rule <- as(rule,"data.frame")
#       rule
#       
#     }else{
      
      transdataCustom <- reactiveFilteredDataIncludingSales()
      categoryLevel <- colnames(transdataCustom)[8]
      transdataCustom <- split(transdataCustom[,eval(categoryLevel)],transdataCustom$Receipt_No)
      listData <- list()
      for (i in 1:length(transdataCustom)) {
        listData[[i]] <- as.character(transdataCustom[[i]][!duplicated(transdataCustom[[i]])])
      }
      
      # changing class of transdata
      transdataCustom <- as(listData,"transactions")
      rule <- apriori(data=transdataCustom, parameter=list(supp=0.01,conf = 0.001,minlen=2), 
                      appearance = list(default="rhs",lhs=input$productCatecoryLevelSelectedTab2Serv),
                      control = list(verbose=F))
      # removing redundant rules
      subset.matrix <- is.subset(rule, rule)
      subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
      redundant <- colSums(subset.matrix, na.rm=T) >= 1
      rules.pruned <- rule[!redundant]
      rule <- rules.pruned
      rule <- as(rule,"data.frame")
      rule$lift <- round(rule$lift,digits = 4)
    # }
    ruleTablePlot <- ggplot(rule, aes(lift))
    ruleTablePlot <- ruleTablePlot + geom_histogram(colour = "#173e4f", fill = "#0078d7",binwidth = .2,origin = min(rule$lift),right = TRUE)
    ruleTablePlot <- ruleTablePlot + xlab("Lift") + ylab("Count")
    ruleTablePlot <- ruleTablePlot + scale_x_continuous(breaks=seq(from =min(rule$lift),to = max(rule$lift),by = .2 ))
    ruleTablePlot <- ruleTablePlot + theme(legend.position="none",
                                           panel.background=element_blank(),
                                           panel.border=element_blank(),
                                           panel.grid.major=element_blank(),
                                           panel.grid.minor=element_blank(),
                                           plot.background=element_blank())
    ruleTablePlot
    
    
    
  })
  
    
  
  output$customRulesTable <- renderDataTable({
    
#     if(input$lhsrhs=="Before"){
#       transdataCustom <- reactiveFilteredDataIncludingSales()
#       categoryLevel <- colnames(transdataCustom)[8]
#       transdataCustom <- split(transdataCustom[,eval(categoryLevel)],transdataCustom$Receipt_No)
#       listData <- list()
#       for (i in 1:length(transdataCustom)) {
#         listData[[i]] <- as.character(transdataCustom[[i]][!duplicated(transdataCustom[[i]])])
#       }
#       
#       # changing class of transdata
#       transdataCustom <- as(listData,"transactions")
#       rule <- apriori(data=transdataCustom, parameter=list(supp=0.01,conf = 0.001,minlen=2), 
#                       appearance = list(default="lhs",rhs=input$productCatecoryLevelSelectedTab2Serv),
#                       control = list(verbose=F))
#       # removing redundant rules
#       subset.matrix <- is.subset(rule, rule)
#       subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
#       redundant <- colSums(subset.matrix, na.rm=T) >= 1
#       rules.pruned <- rule[!redundant]
#       rule <- rules.pruned
#       quality(rule) <- round(quality(rule),digits = 4)
#       rule <- as(rule,"data.frame")
#       rule
#       
#     }else{
      
      transdataCustom <- reactiveFilteredDataIncludingSales()
      categoryLevel <- colnames(transdataCustom)[8]
      transdataCustom <- split(transdataCustom[,eval(categoryLevel)],transdataCustom$Receipt_No)
      listData <- list()
      for (i in 1:length(transdataCustom)) {
        listData[[i]] <- as.character(transdataCustom[[i]][!duplicated(transdataCustom[[i]])])
      }
      
      # changing class of transdata
      transdataCustom <- as(listData,"transactions")
      rule <- apriori(data=transdataCustom, parameter=list(supp=0.01,conf = 0.001,minlen=2), 
                      appearance = list(default="rhs",lhs=input$productCatecoryLevelSelectedTab2Serv),
                      control = list(verbose=F))
      # removing redundant rules
      subset.matrix <- is.subset(rule, rule)
      subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
      redundant <- colSums(subset.matrix, na.rm=T) >= 1
      rules.pruned <- rule[!redundant]
      rule <- rules.pruned
      quality(rule) <- round(quality(rule),digits = 4)
      rule <- as(rule,"data.frame")
      rule <- rule[order(-rule$lift),]
      rule
    # }
    
    
  },options = list(
    lengthChange = FALSE,
    searching = FALSE,
    pageLength = 25,
    orderClasses = TRUE),
  rownames = FALSE,
  colnames =c("Association","Support","Confidence","Lift"))


#   output$barTableOutPut  <- renderDataTable({
#     
#     transdataCustom <- reactiveFilteredDataIncludingSales()
#     categoryLevel <- colnames(transdataCustom)[8]
#     transdataCustom <- split(transdataCustom[,eval(categoryLevel)],transdataCustom$Receipt_No)
#     listData <- list()
#     for (i in 1:length(transdataCustom)) {
#       listData[[i]] <- as.character(transdataCustom[[i]][!duplicated(transdataCustom[[i]])])
#     }
#     
#     # changing class of transdata
#     transdataCustom <- as(listData,"transactions")
#     rule <- apriori(data=transdataCustom, parameter=list(supp=0.01,conf = 0.001,minlen=2), 
#                     appearance = list(default="rhs",lhs=input$productCatecoryLevelSelectedTab2Serv),
#                     control = list(verbose=F))
#     # removing redundant rules
#     subset.matrix <- is.subset(rule, rule)
#     subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
#     redundant <- colSums(subset.matrix, na.rm=T) >= 1
#     rules.pruned <- rule[!redundant]
#     rule <- rules.pruned
#     quality(rule) <- round(quality(rule),digits = 4)
#     rule <- as(rule,"data.frame")
#     
#     minimunLift <- sort(rule$lift,decreasing = FALSE)[1]
#     maximumLift <- sort(rule$lift,decreasing = TRUE)[1]
#     rangeHistigram <- seq(from = minimunLift,to = maximumLift,by = .2)
#     your.number= input$customRulesPlot_dblclick$x
#     index <- which.min(abs(rangeHistigram - your.number))
#     valueAtIndex <- rangeHistigram[index]
#     if(your.number >= valueAtIndex){
#       
#       range <- c(rangeHistigram[index],rangeHistigram[index]+ .2)
#       
#       }else{
#         
#         range <- c(rangeHistigram[index] - .2,rangeHistigram[index])
#         
#       }
#     
#     rule <- subset(rule,rule$lift < range[1], rule$lift > range[2])
#     rule
#     
#   })
  


  
  values <- reactiveValues()
  values$customList <- data.frame()
  values$customReceiptList <- data.frame()

  
  reactiveFilteredRule <- reactive({
    if(input$button == 0)
      return()
    isolate(filterRule(rule = reactiveAssociationRules(),
                       lhs1 = input$lhsInputUI,
                       rhs1 = input$rhsInputUI,
                       support1 = 0,
                       confidence1 = 0,
                       lift1 = 0))
    
  })
 

  
 
  
  

  
  

  
  
})