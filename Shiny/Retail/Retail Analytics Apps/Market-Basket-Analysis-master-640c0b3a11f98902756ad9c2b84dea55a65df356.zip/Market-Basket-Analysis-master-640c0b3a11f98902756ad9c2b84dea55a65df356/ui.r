
library(shiny)
library(shinythemes)
library(DT)
level <- c("Level 1","Level 2","Level 3" )
day <- c("Weekday","Weekend")
gender <-  c("Male","Female")

shinyUI(fluidPage(theme =shinytheme("cosmo"),
                  tags$head(
                    tags$style(type="text/css",".dataTables_filter{display: none;}")
                    ),
  fluidRow(column(3,
                  fluidRow(
                    column(4,
                           
                           div(img(src="logo_light_small_transparentbg.png" ,style="float: left;"))
                           ),
                    column(8,
                           h3("Market Basket",style="float: right;")
                           )
                    ),
                  wellPanel(tags$div(
                    fluidRow(
                      column(6,
                             uiOutput("startDateUI")
                             ),
                      column(6,
                             uiOutput("endDateUI")
                             )
                      ),
                    
                    
                    uiOutput("store"),
                    checkboxGroupInput(label = "",inputId = "Day",choices =day ,inline = TRUE,selected = day[1]),
                    uiOutput("ageUI"),
                    checkboxGroupInput(inputId = "gender",label = "Gender",choices =gender,selected = gender[1],inline = TRUE),
                    selectInput(inputId = "poductCategoryLevel" , label = "Product Hierarchy",choices =level ,selected =level[1]),
                    actionButton(inputId = "getRules",label = "Get Rules" )
                    ))
#                   numericInput(inputId ="support",label = "Support",value = 0),
#                   numericInput(inputId ="confidence",label = "Confidencei",value = 0))
                  
                  ),
           column(9,
                  tabsetPanel(type="tabs",
                              tabPanel("Rules",
                                       fluidRow(
                                         column(12,
                                                plotOutput("top10Affinity"))),
                                       fluidRow(
                                         column(6,
                                                h3("Purchase basket for top frequent items"),
                                                dataTableOutput("top10TransactionFrequency")
                                                ),
                                         column(6,
                                                h3("Purchase basket for top sales generating items"),
                                                dataTableOutput("top10Sales")
                                                )
                                         )
                                       ),
                              tabPanel("Get Affinity",
                                       fluidRow(
                                                column(7,
                                                       h2("What customers bought along with")
                                                       
                                                       ),
#                                                 column(3,
#                                                        selectInput(inputId ="lhsrhs" ,label = "",
#                                                                     choices =list("Before","After") ,multiple = FALSE)
#                                                        
#                                                        ),
                                                column(4,
                                                       uiOutput("productCatecoryLevelSelectedTab2UI"),
                                                       tags$style("#productCatecoryLevelSelectedTab2UI{float:left;}")
                                                       )
                                                
                                                ),
                                       fluidRow(
                                         column(12,
                                                plotOutput("customRulesPlot",height = "300px",
                                                           dblclick ="customRulesPlot_dblclick"),
#                                                 dataTableOutput("barTableOutPut"),
                                                dataTableOutput("customRulesTable")
                                                )
                                         )
                                       )
                              )
                  )
)))