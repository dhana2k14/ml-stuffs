

library(RODBC)
library(reshape2)

# x <- dataIncludingSales(startDate = "2011-02-23",
#                         endDate ="2015-02-23" ,
#                         stores = c("S0001","S0007"),
#                         gender = "Male",
#                         categoryLevel = "Level 1" ,
#                         whatday =c("Weekday","Weekend"),
#                         age = c(30,50))
# y <- getAssociationRules(initialdata)
# 

# function to get data that which includes the sales column as well
dataIncludingSales <- function(startDate,endDate,stores,gender,categoryLevel,whatday,age){
  
  #Pasting start and end date between '' to print them in SQL query
  vcharStartDate1<-paste("'",startDate,"'",sep="")
  vcharEndDate1<-paste("'",endDate,"'",sep="")
  
  categoryLevel <- switch(categoryLevel,
                          "Level 1" = "Product_Group_Code_Desc",
                          "Level 2" = "Level_3_Code_Desc",
                          "Level 3" = "ItemNo_Code_Desc"
                          )
  
  # transdata <- transdata[,c(eval(categoryLevel),"Receipt_No")]
  
  
  #Pasting Stores between '' to print them in SQL query
  if(stores=="All Stores")
  {
    vcharStoreString=paste("'S0001'",",","'S0002'",",","'S0003'",",","'S0004'",",","'S0005'",",","'S0006'",",","'S0007'",",","'S0008'",",","'S0009'",",","'S0010'",",","'S0011'",",","'S0012'",",","'S0013'",",","'S0014'",",","'S0015'",",","'S0017'",",","'S0018'",",","'S0020'",",","'S0021'",",","'S0022'",",","'S0023'",",","'S0024'",",","'S0025'",",","'S0026'",",","'S0027'",",","'S0028'",",","'S0029'",",","'S0032'",",","'S0033'",",","'S0034'",",","'S0035'",",","'S0036'",",","'S0037'",",","'S0038'",",","'S0040'",",","'S0041'",",","'S0042'",",","'S0043'",",","'S0044'",",","'S0045'",",","'S0046'",",","'S0047'",",","'S0048'",",","'S0049'",",","'S0050'",",","'S0051'",",","'S0052'",",","'S0053'",",","'S0057'",",","'S0058'",",","'S0059'")
    
    
  } else {
    if(length(stores)<=1)
    {
      vcharStoreString=paste("'",stores[1],"'",sep="")
      
    } else {
      vcharStoreString=paste("'",stores[1],"'",sep="")
      for(i in 2:length(stores)){
        vcharStoreString <-paste(vcharStoreString,paste("'",stores[i],"'",sep=""),sep=",")
        
      }
    }
    
  }
  
  if(length(gender)==1)
  {
    vcharGender<-paste("'",gender,"'",sep="")
    
    
  } else {
    vcharGender<-paste("'","Male","'",",","'","Female","'",sep="")
  }
  
  
  #Writing a dynamic SQL query to fetch the data with required filters
  #SQLconnection name-retail,user-sa,password-Password123
  if(length(whatday)==2){
  SQLquery <- sprintf('SELECT Store_No,Loyalty_Card_No,Receipt_No,Transaction_date,
                      Age,Gender,Price,%s from
                      [dbo].NTUC_data_mart where Transaction_date >=%s And Transaction_date <%s and Store_No IN (%s) and Gender in (%s) and Age between (%s) and (%s)',categoryLevel,vcharStartDate1,vcharEndDate1,vcharStoreString,vcharGender,age[1],age[2])
  }else{
    if(whatday=="Weekday"){
      
      SQLquery <- sprintf('SELECT Store_No,Loyalty_Card_No,Receipt_No,Transaction_date,
                      Age,Gender,Price,%s from
                      [dbo].NTUC_data_mart where Transaction_date >=%s And Transaction_date <%s and Store_No IN (%s) and Gender in (%s) And  DATEPART(dw,Transaction_date) not in (1,7)',categoryLevel,vcharStartDate1,vcharEndDate1,vcharStoreString,vcharGender)
      
    }else{
      SQLquery <- sprintf('SELECT Store_No,Loyalty_Card_No,Receipt_No,Transaction_date,
                      Age,Gender,Price,%s from
                      [dbo].NTUC_data_mart where Transaction_date >=%s And Transaction_date <%s and Store_No IN (%s) and Gender in (%s) And  DATEPART(dw,Transaction_date)  in (1,7)',categoryLevel,vcharStartDate1,vcharEndDate1,vcharStoreString,vcharGender)
      
    }
  }
  
  SQLconn <-odbcConnect("retail", uid="sa", pwd="Password123")
  vcharSQLResult=sqlQuery(SQLconn, SQLquery)
  close(SQLconn)
  
  transdata <- as.data.frame(vcharSQLResult,stringsAsFactors=FALSE)
  transdata
  
}


datafilter <- function(startDate,endDate,stores,items,gender,categoryLevel,whatday,age){
# 
#   #Pasting start and end date between '' to print them in SQL query
#   vcharStartDate1<-paste("'",startDate,"'",sep="")
#   vcharEndDate1<-paste("'",endDate,"'",sep="")
#   
#   categoryLevel <- switch(categoryLevel,
#                           "Level 1" = "Product_Group_Code_Desc",
#                           "Level 2" = "Level_3_Code_Desc",
#                           "Level 3" = "ItemNo_Code_Desc"
#   )
#   
#   # transdata <- transdata[,c(eval(categoryLevel),"Receipt_No")]
#   
# 
#  
#   #Pasting Stores between '' to print them in SQL query
#   if(stores=="All Stores")
#   {
#     vcharStoreString=paste("'S0001'",",","'S0002'",",","'S0003'",",","'S0004'",",","'S0005'",",","'S0006'",",","'S0007'",",","'S0008'",",","'S0009'",",","'S0010'",",","'S0011'",",","'S0012'",",","'S0013'",",","'S0014'",",","'S0015'",",","'S0017'",",","'S0018'",",","'S0020'",",","'S0021'",",","'S0022'",",","'S0023'",",","'S0024'",",","'S0025'",",","'S0026'",",","'S0027'",",","'S0028'",",","'S0029'",",","'S0032'",",","'S0033'",",","'S0034'",",","'S0035'",",","'S0036'",",","'S0037'",",","'S0038'",",","'S0040'",",","'S0041'",",","'S0042'",",","'S0043'",",","'S0044'",",","'S0045'",",","'S0046'",",","'S0047'",",","'S0048'",",","'S0049'",",","'S0050'",",","'S0051'",",","'S0052'",",","'S0053'",",","'S0057'",",","'S0058'",",","'S0059'")
#     
#     
#   } else {
#     if(length(stores)<=1)
#     {
#       vcharStoreString=paste("'",stores[1],"'",sep="")
#       
#     } else {
#       vcharStoreString=paste("'",stores[1],"'",sep="")
#       for(i in 2:length(stores)){
#         vcharStoreString <-paste(vcharStoreString,paste("'",stores[i],"'",sep=""),sep=",")
#         
#       }
#     }
#     
#   }
#   
#   if(length(gender)==1)
#   {
#     vcharGender<-paste("'",gender,"'",sep="")
#     
#     
#   } else {
#     vcharGender<-paste("'","Male","'",",","'","Female","'",sep="")
#   }
#   
#   
#   #Writing a dynamic SQL query to fetch the data with required filters
#   #SQLconnection name-retail,user-sa,password-Password123
#   SQLquery <- sprintf('SELECT Store_No,Loyalty_Card_No,Receipt_No,Transaction_date,
#                       Age,Gender,Price,%s from [dbo].NTUC_data_mart where Transaction_date >=%s And Transaction_date <%s and Store_No IN (%s) and Gender in (%s)',categoryLevel,vcharStartDate1,vcharEndDate1,vcharStoreString,vcharGender)
#   
#   SQLconn <-odbcConnect("retail", uid="sa", pwd="Password123")
#   vcharSQLResult=sqlQuery(SQLconn, SQLquery)
#   close(SQLconn)
#   
#   transdata <- as.data.frame(vcharSQLResult,stringsAsFactors=FALSE)
#   
#   if(length(whatday)==2){
#     
#     transdata <- subset(transdata,transdata$Transaction_date >= as.Date(startdate,format = "%m/%d/%Y") &
#                           transdata$Transaction_date <= as.Date(enddate,format = "%m/%d/%Y") )
#     
#   }else{
#     if(whatday=="Weekday"){
#       transdata <- transdata[!(weekdays(as.Date(transdata$Transaction_date)) %in% c('Saturday','Sunday')),]
#     }else{
#       transdata <- transdata[(weekdays(as.Date(transdata$Transaction_date)) %in% c('Saturday','Sunday')),]
#       
#     }
#     
#   }
#   
# 
# 
#   transdata <- subset(transdata, transdata$Age > age[1] & transdata$Age >= age[2])
# # transdata <- transdata[,c(eval(categoryLevel),"Receipt_No")]
#   transdata <- split(transdata[,eval(categoryLevel)],transdata$Receipt_No)
#   transactionlist <- transdata
}


getAssociationRules <- function(filterdata){
#   transdata1 <- initialdata
  transdata1 <- filterdata
  categoryLevel <- colnames(transdata1)[8]
  transdata1 <- split(transdata1[,eval(categoryLevel)],transdata1$Receipt_No)

  # removing duplicate item values in every transaction
  listData <- list()
  for (i in 1:length(transdata1)) {
    listData[[i]] <- as.character(transdata1[[i]][!duplicated(transdata1[[i]])])
  }
  
  # changing class of transdata
  transdata1 <- as(listData,"transactions")

  # association rules
  basket_rules <- apriori(data = transdata1, 
                          parameter = list(sup = .01,
                                           conf = .05,
                                           minlen = 2
                                           )
                          )
  
  basket_rules <- unique(basket_rules)
  basket_rules <- sort( basket_rules,by= "lift",decreasing = TRUE )
  basket_rules <- basket_rules[1:20]
  
  # removing redundant rules
#   subset.matrix <- is.subset(basket_rules, basket_rules)
#   subset.matrix[lower.tri(subset.matrix, diag=T)] <- NA
#   redundant <- colSums(subset.matrix, na.rm=T) >= 1
#   rules.pruned <- basket_rules[!redundant]
#   basket_rules <- rules.pruned
#   quality(basket_rules) <- round(quality(basket_rules),digits = 4)
#   basket_rules <- unique(basket_rules)
#   basket_rules
  
}


getRulesByItems <- function(item,transdata){
  
  # removing duplicate item values in every transaction
  listData <- list()
  for (i in 1:length(transdata)) {
    listData[[i]] <- as.character(transdata[[i]][!duplicated(transdata[[i]])])
  }
  transdata <- as(listData,"transactions")
  rules <- apriori(data=transdata, parameter=list(supp=0.000,conf = 0.00,minlen=2), 
                   appearance = list(default="lhs",rhs=item),
                   control = list(verbose=F))
  rules <- sort(rules, decreasing=TRUE,by="confidence")
  rules <- rules[1:5]
  rules <- as(rules,"data.frame")
  rules
  
}


