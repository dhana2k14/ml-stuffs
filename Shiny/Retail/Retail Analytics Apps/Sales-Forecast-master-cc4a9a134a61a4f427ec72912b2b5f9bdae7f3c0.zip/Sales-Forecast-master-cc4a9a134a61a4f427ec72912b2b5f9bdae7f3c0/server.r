library(shiny)
library(plotly)
library(dygraphs)
library(forecast)

source("forecasting.r")

shinyServer(function(input, output,session) {
  
  observe({
    if(is.null(input$storeServ) || input$storeServ =="" ||
       is.null(input$itemCategoryServ) || input$itemCategoryServ =="" || 
       is.null(input$startDateServ)
    )
        
     {
      shinyjs::disable("goButton")
    } else {
      shinyjs::enable("goButton")
    }
  })
  
  defaultData <- getForecastData(startDate="2010-01-01",
                              stores = 10140,
                              categorys = "APPAREL",
                              forecast1 = "Weekly"
    
  )
  
  #default data for sales forecast chart
  defaultData1 <- getForecastData1(startDate1="2010-01-01",
                                 stores1 = 10140,
                                 categorys1 = "APPAREL",
                                 forecast2 = "Weekly"
                                 
  )
  
  sales_CondVar<-reactiveValues(
    condVar1=1
  )
  
  observeEvent(input$goButton, {
    sales_CondVar$condVar1 <- sales_CondVar$condVar1 +1
    
  })
  
  
  output$storeDatasetUI <-renderUI({
    selectizeInput(
      "storeServ", 
      label="Store ", 
      choices = store_ddl() ,
      selected = store_ddl()[1],
      multiple = TRUE)
    
    
  })
  
  output$itemcategoryUI <-renderUI({
    
    selectizeInput(
      "itemCategoryServ", label="Item Category ", choices = itemCategory_ddl(), multiple = TRUE ,selected = itemCategory_ddl()[1]
    )
  })

 
output$startDateUI <- renderUI({

  dateInput("startDateServ", label="Analysis Start Date", min='2014-11-01 00:00:00',max = '2015-10-31 00:00:00',format = "yyyy-mm-dd", value = '2014-11-01 00:00:00') 
            
}) 
  


reactiveData <-reactive({
  
  
  input$goButton
  
  
  isolate(
    
    
  getForecastData(startDate = input$startDateServ,
                  stores = input$storeServ,
                  categorys = input$itemCategoryServ,
                  forecast1 = input$forecast))
        
  
})

#taking user-input data for sales forecast chart(weekly) using reactive block
reactiveData1 <-reactive({
  
  
  input$goButton
  
  
  isolate(
    
    
    getForecastData1(startDate1 = input$startDateServ,
                    stores1 = input$storeServ,
                    categorys1 = input$itemCategoryServ,
                    forecast2 = input$forecast))
  
  
})

#taking user-input data for sales forecast chart(monthly) using reactive block
reactiveData2 <-reactive({
  
  
  input$goButton
  
  
  isolate(
    
    
    getForecastData2(startDate2 = input$startDateServ,
                     stores2 = input$storeServ,
                     categorys2 = input$itemCategoryServ,
                     forecast3 = input$forecast))
  
  
})

#taking user-input data for sales forecast chart(quarterly) using reactive block
reactiveData3 <-reactive({
  
  
  input$goButton
  
  
  isolate(
    
    
    getForecastData3(startDate3 = input$startDateServ,
                     stores3 = input$storeServ,
                     categorys3 = input$itemCategoryServ,
                     forecast4 = input$forecast))
  
  
})


#displaying line-chart in the dashboard using plotly package
output$salestimeseries <- renderPlotly({
  f1 <- list(
    family = "Arial, sans-serif",
    size = 18,
    color = "black"
  )
  ax <- list(title = "Month",titlefont = f1)
  ay <- list(title = "Sales in $",titlefont = f1)
  if(sales_CondVar$condVar1==1){
    defaultData <- as.data.frame(defaultData)
    x<-sort(defaultData$transaction_date,decreasing = FALSE)
    #x<-list(title("date"))
    y <- defaultData$Total_Sales
    #y <- list(title("sales in $"))
    p <- plot_ly(x = x, y = y) %>% 
      layout(xaxis = ax, yaxis = ay)
  }
  else{
    reactiveData <- as.data.frame(reactiveData())
    x <- sort(reactiveData$transaction_date,decreasing = FALSE)
    y <- reactiveData$Total_Sales
    p <- plot_ly(x = x, y = y)  %>% 
      layout(xaxis = ax, yaxis = ay)
  }
  p
}
)


#displaying decomposition-chart in the dashboard using plotly package
output$decomposeChart <- renderPlotly({
  
  reactiveData <- as.data.frame(reactiveData())
  f1 <- list(
    family = "Arial, sans-serif",
    size = 12,
    color = "black"
  )
  ax <- list(title = "" ,titlefont = f1)
  bx <- list(title = "Month",titlefont = f1)
  ay <- list(title = "Observed",titlefont = f1)
  by <- list(title = "Seasonal",titlefont = f1)
  cy <- list(title = "Trend",titlefont = f1)
  dy <- list(title = "Remainder",titlefont = f1)
  if(sales_CondVar$condVar1==1){

    defaultData <- as.data.frame(defaultData)
    x <- defaultData$Total_Sales
    frequency1 = 52
    salests<-ts(x,frequency = frequency1)
    w <- stl(x = salests, s.window = "periodic")
    stable <- as.data.frame(w$time.series[,1])
    ttable <- as.data.frame(w$time.series[,2])
    rtable <- as.data.frame(w$time.series[,3])
    first_table <- cbind(defaultData$Total_Sales,stable$x,ttable$x,rtable$x)
    first_table <- as.data.frame(first_table)
    final_table <- cbind((as.character.Date(defaultData$transaction_date)),first_table)
    final_table <- as.data.frame(final_table)
    z <- final_table
    
    x1<-sort(defaultData$transaction_date ,decreasing = FALSE)
    y1 <- z$`defaultData$Total_Sales`
    plot1 <- plot_ly(x = x1, y = y1,name = "Observed sales value") %>% 
      layout(xaxis = ax, yaxis = ay)
    
    x2 <- sort(defaultData$transaction_date, decreasing = FALSE)
    y2 <- z$`stable$x`
    plot2 <- plot_ly(x = x2, y = y2,name = "Seasonal value") %>% 
      layout(xaxis = ax,yaxis = by)
    
    x3 <- sort(defaultData$transaction_date, decreasing = FALSE)
    y3 <- z$`ttable$x`
    plot3 <- plot_ly(x = x3, y = y3,name = "Trend value") %>% 
      layout(xaxis = ax,yaxis = cy)
    
    x4 <- sort(defaultData$transaction_date, decreasing = FALSE)
    y4 <- z$`rtable$x`
    plot4 <- plot_ly(x = x4, y = y4,name = "Remainder value") %>% 
      layout(xaxis = bx,yaxis = dy)
    
    
    plot5 <- subplot(plot1,plot2,plot3,plot4,nrows = 4) 
    
    
  }
  
  else{
    
    if(input$forecast == "Weekly"){
      reactiveData <- as.data.frame(reactiveData())
      x <- reactiveData
      frequency1 = 52
      plot5 <- decomposeFun(x,frequency1)
      }
      else if(input$forecast == "Monthly"){
        reactiveData <- as.data.frame(reactiveData())
        x <- reactiveData
        frequency1 = 12
        plot5 <- decomposeFun(x,frequency1)
      }
      else{
        reactiveData <- as.data.frame(reactiveData())
        x <- reactiveData
        frequency1 = 4
        plot5 <- decomposeFun(x,frequency1)
      }
  }
  plot5
  
}
)

  
#displaying forecasting-chart in the dashboard using plotly package
output$salesForecastChart <- renderPlotly({
  reactiveData1 <- as.data.frame(reactiveData1())
  reactiveData2 <- as.data.frame(reactiveData2())
  reactiveData3 <- as.data.frame(reactiveData3())
  if(sales_CondVar$condVar1==1){
    f1 <- list(
      family = "Arial, sans-serif",
      size = 14,
      color = "black"
    )
    ax <- list(title = "Week",titlefont = f1)
    ay <- list(title = "Sales in $",titlefont = f1)
    defaultData1 <- as.data.frame(defaultData1)
    x <- defaultData1
    frequency1 = 52
    salests<-ts(x$Total_Sales,frequency = frequency1)
    fit <- auto.arima(salests)
    salestsforecast <- forecast(fit, h=3)
    binding_table <- as.data.frame(salestsforecast)
    binding_table$transweek <- c(53,54,55)  
    binding_table$Total_Sales <- binding_table$`Point Forecast`
    plot1 <-  plot_ly(data = x,x= x$transweek,y=x$Total_Sales,name = "Actual sales")  %>% add_trace(binding_table ,x=binding_table$transweek,y=binding_table$Total_Sales,name = "Forecasted sales") %>% layout(xaxis = ax, yaxis = ay)
    plot1
    
  }
  else{
    if(input$forecast == "Weekly"){
        reactiveData1 <- as.data.frame(reactiveData1())
        x <- reactiveData1
        frequency1 = 52
        plot1<-salesForecastFun1(x,frequency1)
        plot1
    }
    else if(input$forecast == "Monthly"){
        reactiveData2 <- as.data.frame(reactiveData2())
        x <- reactiveData2
        frequency1 = 12
        plot1<-salesForecastFun2(x,frequency1)
        plot1
    }
    else{
        reactiveData3 <- as.data.frame(reactiveData3())
        x <- reactiveData3
        frequency1 = 4
        plot1<-salesForecastFun3(x,frequency1)
        plot1
    }
  }
  
  
}
)
    
    
  
})


    