#Import libraries
library(class)
library(colorspace)
library(digest)
library(RODBC)
library(Rcpp)
library(plyr)
library(quadprog)
library(quantmod)
library(forecast)


#function to get stores data from sql to display in dashboard icon
store_ddl<-function(){
  
  myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
  
  #query=  "SELECT 
  #from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final]"
  
  query="SELECT distinct(store)
  from [Retail_MSCRM].[dbo].[master_store]"
  
  result_store=sqlQuery(myconn, query)
  
#   result_store<-as.data.frame(as.character(result_store))
  result_store$store
}

#function to get category data from sql to display in dashboard icon
itemCategory_ddl<-function(){
  
  myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
  
  
  query="SELECT distinct(category)
  from [Retail_MSCRM].[dbo].[master_category]"
  
  result_category=sqlQuery(myconn, query)
  result_category = na.omit(result_category)
  #result_category<-as.character(result_category)
  as.character(result_category$category)
  
}

#function to get transaction date from SQL to display in dashboard icon
date_calender<-function(){
  
  myconn <-odbcConnect("retail", uid="sa", pwd="Password123")
  
  
  
#   query="SELECT \'2014-11-01 00:00:00\' as min_date, \'2015-10-31 00:00:00\' as max_date
#   from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final]"
  
#   result_date=sqlQuery(myconn, query)
#   result_min_date=as.Date(result_date$min_date)
#   result_max_date=as.Date(result_date$max_date)
#   final_result_date=c(result_min_date,result_max_date)
  final_result_date=c('2014-11-01 00:00:00','2015-10-31 00:00:00')
  

}


#function to pass the user provided input as parametres and fetch the required data from SQL
getForecastData<-function(startDate,stores,categorys,forecast1)
{  
  #Pasting start date between '' to print them in SQL query
  vcharstartDate1<-paste("'",startDate,"'",sep="")
  
  #Pasting category  between '' to print them in SQL query
    if(length(categorys)<=1)
    {
      vcharcategoryString=paste("'",categorys[1],"'",sep="")
    } else {
      vcharcategoryString=paste("'",categorys[1],"'",sep="")
      for(i in 2:length(categorys)){
        vcharcategoryString <-paste(vcharcategoryString,paste("'",categorys[i],"'",sep=""),sep=",")
        
      }
    }
  
  #Pasting Stores between '' to print them in SQL query
    if(length(stores)<=1)
    {
      vcharStoreString=paste("'",stores[1],"'",sep="")
      
    } else {
      vcharStoreString=paste("'",stores[1],"'",sep="")
      for(i in 2:length(stores)){
        vcharStoreString <-paste(vcharStoreString,paste("'",stores[i],"'",sep=""),sep=",")
        
      }
    }
  
  #Writing a dynamic SQL query to fetch the data with required filters
  #SQLconnection name-retail,user-sa,password-Password123
  SQLquery <- sprintf('SELECT transaction_date,sum(quantity)as Total_Sales  
                      from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final] 
                      where transaction_date >=%s and category IN (%s)And store IN (%s) 
                      group by transaction_date',vcharstartDate1,vcharcategoryString,vcharStoreString)
  
  SQLconn <-odbcConnect("retail", uid="sa", pwd="Password123")
  vcharSQLResult=sqlQuery(SQLconn, SQLquery)
  close(SQLconn)
  dfSQLResult<-as.data.frame(vcharSQLResult,stringsAsFactors=FALSE)
}



# function to fetch data from SQL and arrange it as per weekly view
getForecastData1<-function(startDate1,stores1,categorys1,forecast2)
{  
  #Pasting start date between '' to print them in SQL query
  vcharstartDate2<-paste("'",startDate1,"'",sep="")

  #Pasting category between '' to print them in SQL query
  if(length(categorys1)<=1)
  {
    vcharcategoryString1=paste("'",categorys1[1],"'",sep="")
  } else {
    vcharcategoryString1=paste("'",categorys1[1],"'",sep="")
    for(i in 2:length(categorys1)){
      vcharcategoryString1 <-paste(vcharcategoryString1,paste("'",categorys1[i],"'",sep=""),sep=",")
      
    }
  }
  
  #Pasting Stores between '' to print them in SQL query
  if(length(stores1)<=1)
  {
    vcharStoreString1=paste("'",stores1[1],"'",sep="")
    
  } else {
    vcharStoreString1=paste("'",stores1[1],"'",sep="")
    for(i in 2:length(stores1)){
      vcharStoreString1 <-paste(vcharStoreString1,paste("'",stores1[i],"'",sep=""),sep=",")
      
    }
  }

  #Writing a dynamic SQL query to fetch the data with required filters
  #SQLconnection name-retail,user-sa,password-Password123
  
  SQLquery <- sprintf('SELECT DATEPART(WK,transaction_date) AS transweek,sum(quantity)as Total_Sales  
                      from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final] 
                      where transaction_date >=%s and category IN (%s)And store IN (%s) 
                      group by DATEPART(WK,transaction_date) order by transweek',vcharstartDate2,vcharcategoryString1,vcharStoreString1)
  
  SQLconn1 <-odbcConnect("retail", uid="sa", pwd="Password123")
  vcharSQLResult1=sqlQuery(SQLconn1, SQLquery)
  close(SQLconn1)
  dfSQLResult1<-as.data.frame(vcharSQLResult1,stringsAsFactors=FALSE)
}


#function to fetch data from SQL and arrange it as per mothly view
getForecastData2<-function(startDate2,stores2,categorys2,forecast3)
{  
  #Pasting start date between '' to print them in SQL query
  vcharstartDate3<-paste("'",startDate2,"'",sep="")

  #Pasting category category between '' to print them in SQL query
  if(length(categorys2)<=1)
  {
    vcharcategoryString2=paste("'",categorys2[1],"'",sep="")
  } else {
    vcharcategoryString2=paste("'",categorys2[1],"'",sep="")
    for(i in 2:length(categorys2)){
      vcharcategoryString2 <-paste(vcharcategoryString2,paste("'",categorys2[i],"'",sep=""),sep=",")
      
    }
  }
  
  #Pasting Stores between '' to print them in SQL query
  if(length(stores2)<=1)
  {
    vcharStoreString2=paste("'",stores2[1],"'",sep="")
    
  } else {
    vcharStoreString2=paste("'",stores2[1],"'",sep="")
    for(i in 2:length(stores2)){
      vcharStoreString2 <-paste(vcharStoreString2,paste("'",stores2[i],"'",sep=""),sep=",")
      
    }
  }
  
  #Writing a dynamic SQL query to fetch the data with required filters
  #SQLconnection name-retail,user-sa,password-Password123
  SQLquery <- sprintf('SELECT DATEPART(MM,transaction_date) AS transmonth,sum(quantity)as Total_Sales  
                      from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final] 
                      where transaction_date >=%s and category IN (%s)And store IN (%s) 
                      group by DATEPART(MM,transaction_date) order by transmonth',vcharstartDate3,vcharcategoryString2,vcharStoreString2)
  
  SQLconn2 <-odbcConnect("retail", uid="sa", pwd="Password123")
  vcharSQLResult2=sqlQuery(SQLconn2, SQLquery)
  close(SQLconn2)
  dfSQLResult2<-as.data.frame(vcharSQLResult2,stringsAsFactors=FALSE)
}


##function to fetch data from SQL and arrange it as per quarterly view
getForecastData3<-function(startDate3,stores3,categorys3,forecast4)
{  
  #Pasting start date between '' to print them in SQL query
  vcharstartDate4<-paste("'",startDate3,"'",sep="")
  
  #Pasting category between '' to print them in SQL query
  if(length(categorys3)<=1)
  {
    vcharcategoryString3=paste("'",categorys3[1],"'",sep="")
  } else {
    vcharcategoryString3=paste("'",categorys3[1],"'",sep="")
    for(i in 2:length(categorys3)){
      vcharcategoryString3 <-paste(vcharcategoryString3,paste("'",categorys3[i],"'",sep=""),sep=",")
      
    }
  }
  
  #Pasting Stores between '' to print them in SQL query
  if(length(stores3)<=1)
  {
    vcharStoreString3=paste("'",stores3[1],"'",sep="")
    
  } else {
    vcharStoreString3=paste("'",stores3[1],"'",sep="")
    for(i in 2:length(stores3)){
      vcharStoreString3 <-paste(vcharStoreString3,paste("'",stores3[i],"'",sep=""),sep=",")
      
    }
  }
  
  #Writing a dynamic SQL query to fetch the data with required filters
  #SQLconnection name-retail,user-sa,password-Password123
  
  SQLquery <- sprintf('SELECT DATEPART(QQ,transaction_date) AS transquarter,sum(quantity)as Total_Sales  
                      from [Retail_MSCRM].[dbo].[sales_forecasting_joined_final] 
                      where transaction_date >=%s and category IN (%s)And store IN (%s) 
                      group by DATEPART(QQ,transaction_date) order by transquarter',vcharstartDate4,vcharcategoryString3,vcharStoreString3)
  
  SQLconn3 <-odbcConnect("retail", uid="sa", pwd="Password123")
  vcharSQLResult3=sqlQuery(SQLconn3, SQLquery)
  close(SQLconn3)
  dfSQLResult3<-as.data.frame(vcharSQLResult3,stringsAsFactors=FALSE)
}


#function to decompose the provided time-series object
#function uses Seasonal Trend Decomposition algorithm(STL)
#input -> data frame and frequency, output -> decomposition plot

decomposeFun <- function(x,frequency1)
{
  #font description for labels in decompose chart
  f1 <- list(
    family = "Arial, sans-serif",
    size = 12,
    color = "black"
  )
  #layout for chart
  ax <- list(title = "",titlefont = f1)
  bx <- list(title = "Month",titlefont = f1)
  ay <- list(title = "Observed",titlefont = f1)
  by <- list(title = "Seasonal",titlefont = f1)
  cy <- list(title = "Trend",titlefont = f1)
  dy <- list(title = "Remainder",titlefont = f1)
  #time series calculation
  salests<-ts(x$Total_Sales,frequency = frequency1)
  #decomposition using 'stl' algorithm
  w <- stl(x = salests, s.window = "periodic")
  stable <- as.data.frame(w$time.series[,1])
  ttable <- as.data.frame(w$time.series[,2])
  rtable <- as.data.frame(w$time.series[,3])
  first_table <- cbind(x$Total_Sales,stable$x,ttable$x,rtable$x)
  first_table <- as.data.frame(first_table)
  final_table <- cbind((as.character.Date(x$transaction_date)),first_table)
  final_table <- as.data.frame(final_table)
  z <- final_table
  
  #ploting 4 different plots for all 4 variables from stl object in y-axis
  x1<-sort(x$transaction_date ,decreasing = FALSE)
  y1 <- z$`x$Total_Sales`
  plot1 <- plot_ly(x = x1, y = y1,name = "Observed sales value") %>% 
    layout(xaxis = ax, yaxis = ay)
  
  x2 <- sort(x$transaction_date, decreasing = FALSE)
  y2 <- z$`stable$x`
  plot2 <- plot_ly(x = x2, y = y2,name = "Seasonal value") %>% 
    layout(xaxis = ax, yaxis = by)
  
  x3 <- sort(x$transaction_date, decreasing = FALSE)
  y3 <- z$`ttable$x`
  plot3 <- plot_ly(x = x3, y = y3,name = "Trend value") %>% 
    layout(xaxis = ax, yaxis = cy)
  
  x4 <- sort(x$transaction_date, decreasing = FALSE)
  y4 <- z$`rtable$x`
  plot4 <- plot_ly(x = x4, y = y4,name = "Remainder value") %>% 
    layout(xaxis = bx, yaxis = dy)
  
  #combining all the above 4 plots together using subplot function
  finalplot <- subplot(plot1,plot2,plot3,plot4, nrows = 4)
  
}


  
#function for calculating Sales Forecast for week-wise data
#input -> dataframe and frequency, output -> forecastplot
salesForecastFun1 <- function(x, frequency1)
{
  #font description for labels in forecast chart
  f1 <- list(
    family = "Arial, sans-serif",
    size = 14,
    color = "black"
  )
  ax <- list(title = "Week",titlefont = f1)
  ay <- list(title = "Sales in $",titlefont = f1)
  
  #time-series calculation
  salests<-ts(x$Total_Sales,frequency = frequency1)
  
  #fitting the timeseries object to arima model
  fit <- auto.arima(salests)
  
  #forecasting
  salestsforecast <- forecast(fit, h=3)
  binding_table <- as.data.frame(salestsforecast)
  binding_table$transweek <- c(as.numeric(x$transweek[length(x$transweek)]+1),as.numeric(x$transweek[length(x$transweek)]+2),as.numeric(x$transweek[length(x$transweek)]+3))
  binding_table$Total_Sales <- binding_table$`Point Forecast`
  p <-  plot_ly(data = x,x= x$transweek,y=x$Total_Sales,name = "Actual sales")  %>% add_trace(binding_table ,x=binding_table$transweek,y=binding_table$Total_Sales,name = "Forecasted sales") %>% layout(xaxis = ax, yaxis = ay)
  

}
  
#function for calculating Sales Forecast for month-wise data
#input -> dataframe and frequency, output -> forecastplot

salesForecastFun2 <- function(x, frequency1)
{
  #font description for labels in forecast chart
  f1 <- list(
    family = "Arial, sans-serif",
    size = 14,
    color = "black"
  )
  ax <- list(title = "Month",titlefont = f1)
  ay <- list(title = "Sales in $",titlefont = f1)
  
  #time-series calculation
  salests<-ts(x$Total_Sales,frequency = frequency1)
  
  #fitting the timeseries object to arima model
  fit <- auto.arima(salests)
  
  #forecasting
  salestsforecast <- forecast(fit, h=3)
  binding_table <- as.data.frame(salestsforecast)
  binding_table$transmonth <- c(as.numeric(x$transmonth[length(x$transmonth)]+1),as.numeric(x$transmonth[length(x$transmonth)]+2),as.numeric(x$transmonth[length(x$transmonth)]+3))    
  binding_table$Total_Sales <- binding_table$`Point Forecast`
  p <-  plot_ly(data = x,x= x$transmonth,y=x$Total_Sales,name = "Actual sales")  %>% add_trace(binding_table ,x=binding_table$transmonth,y=binding_table$Total_Sales,name = "Forecasted sales") %>% layout(xaxis = ax, yaxis = ay)
  
  
} 
  
#function for calculating Sales Forecast for quarter-wise data
#input -> dataframe and frequency, output -> forecastplot 

salesForecastFun3 <- function(x, frequency1)
{
  #font description for labels in forecast chart
  f1 <- list(
    family = "Arial, sans-serif",
    size = 14,
    color = "black"
  )
  ax <- list(title = "Quarters",titlefont = f1)
  ay <- list(title = "Sales in $",titlefont = f1)
  
  #time-series calculation
  salests<-ts(x$Total_Sales,frequency = frequency1)
  
  #fitting the timeseries object to arima model
  fit <- auto.arima(salests)
  
  #forecasting
  salestsforecast <- forecast(fit, h=3)
  binding_table <- as.data.frame(salestsforecast)
  binding_table$transquarter <- c(as.numeric(x$transquarter[length(x$transquarter)]+1),as.numeric(x$transquarter[length(x$transquarter)]+2),as.numeric(x$transquarter[length(x$transquarter)]+3))    
  binding_table$Total_Sales <- binding_table$`Point Forecast`
  p <-  plot_ly(data = x,x= x$transquarter,y=x$Total_Sales,name = "Actual sales")  %>% add_trace(binding_table ,x=binding_table$transquarter,y=binding_table$Total_Sales,name = "Forecasted sales") %>% layout(xaxis = ax, yaxis = ay)
  
  
} 

  
 


