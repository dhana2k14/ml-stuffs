library(shiny)
library(shinythemes)
library(ggplot2)
library(labeling)
library(DT)
library(forecast)

shinyUI(fluidPage(theme =shinytheme("Cosmo"),
                  shinyjs::useShinyjs(),
                  fluidRow(
                    column(3,
                           fluidRow(column(4,
                           div(img(src="logo_light_small_transparentbg.png" ,style="float: left;"))),
                           column(8,
                                  h4("Sales Forecasting",
                                     style = "float: right;
                                     font-family: 'calibri';
                                     font-size: 25px;
                                     padding-left: 0px;
                                     padding-top: 0px;
                                     color: #666666;"
                           )
                    )
           ),
           
           wellPanel(style="padding-left: 5px ",
                     uiOutput("startDateUI"),
                     uiOutput("storeDatasetUI"),
                     uiOutput("itemcategoryUI"),
                     checkboxGroupInput(inputId="gen", label="Select Gender", c("Female","Male"), selected = NULL),
                     br(),
                     sliderInput("age", "Age Range", min=20, max=60, value=c(25,50)),
                     br(),
                     radioButtons("forecast",label="Forecast",choices=list("Weekly","Monthly","Quarterly"),selected = "Weekly"),
                     br(),
                     actionButton("goButton","Get Forecast")
                   ) 
    ),
    
    column(9,
           div(plotly::plotlyOutput("salestimeseries")),
           br(),
    
           fluidRow(
             column(6,div(plotly::plotlyOutput("salesForecastChart"))
             ),
             column(6,div(plotly::plotlyOutput("decomposeChart"))
             ))
    )
                  )
))
           
           
                   
           
                  
    
    
           
           
          
           
           
           
           
           
           
           
           

             
             
            
             
           