The application requires following platform versions:
R 3.2.3 ,R Studio 0.99.473,SQL server 2012(Express edition),R Shiny-12.0
Shiny server  1.3.0.403(Node js 0.10.21),
Ubuntu  14.10(utopic),
shiny package  12.0

Input file: [Retail_MSCRM].[dbo].[NTUC_data_mart ]
Output file: RFM Webapp 