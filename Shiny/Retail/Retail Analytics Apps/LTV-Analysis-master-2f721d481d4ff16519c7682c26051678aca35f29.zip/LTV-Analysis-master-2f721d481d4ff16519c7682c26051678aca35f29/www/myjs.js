$(document).ready(function(){
    $("#shinyin").keyup(function(){
        $("#input").val($(this).val())
    });
   
});